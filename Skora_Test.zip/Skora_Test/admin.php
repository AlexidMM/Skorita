<?php
    session_start();
    require 'php/conexion.php';

    // Verificar si el usuario ha iniciado sesión y si es administrador
    if (!isset($_SESSION['nom_us']) || $_SESSION['tipo_us'] != '1') {
        echo '
            <script>
                alert("Acceso denegado. Solo los administradores pueden acceder a esta página.");
                window.location = "login.php";
            </script>
        ';
        exit;
    }

    if (isset($_COOKIE['usuario'])) {
        $nom_us = $_COOKIE['usuario'];
        echo "Bienvenidx, $nom_us";
    }else{
        echo "Usuario no reconocido";
    }

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Pantalla Admin</title>
        <link href="assets/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/css/all.min.css" rel="stylesheet">
</head>
<body class="d-flex flex-column h-100" >
   <div class="container py-3 text-center">
    <a href="php/CRUDS/Articulos/Articulos.php" class="btn btn-primary mx-2">Artículos</a>
    <a href="php/CRUDS/Categorías/categorias.php" class="btn btn-primary mx-2">Categorías</a>
    <a href="php/CRUDS/Inventarios/Inventarios.php" class="btn btn-primary mx-2">Inventarios</a>
    
</div>
    <style>
    @media (max-width: 768px) {
       .table-responsive {
            overflow-x: auto;
        }
       .btn-sm {
            font-size: 12px;
            padding: 5px 10px;
        }
    }

    @media (max-width: 480px) {
       .table-responsive {
            overflow-x: auto;
        }
       .btn-sm {
            font-size: 10px;
            padding: 3px 5px;
        }
    }
    </style>
    <footer class="footer mt-auto py-3 bg-light">
        <div class="container">
        </div>
    </footer>
    
    <script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>
