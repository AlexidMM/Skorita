<?php
    session_start();
    include 'conexion.php';

    // Obtener los datos del formulario
    $nom_us = $_POST['nom_us'];
    $pass_us = $_POST['pass_us'];

    // Consulta para verificar el usuario y obtener el tipo de usuario
    $valid_login = mysqli_query($conexion, "SELECT tipo_us FROM USUARIO WHERE nom_us='$nom_us' AND pass_us='$pass_us'");

    // Verificar si se encontró el usuario
    if (mysqli_num_rows($valid_login) > 0) {
        // Obtener el tipo de usuario
        $row = mysqli_fetch_assoc($valid_login);
        $tipo_us = $row['tipo_us'];
        $_SESSION['nom_us']=$nom_us;
        $_SESSION['tipo_us']=$tipo_us;

    setcookie('usuario', $nom_us, time() + 84600, "/");

        // Redirigir según el tipo de usuario
        if ($tipo_us == '1') {
            header("location: ../admin.php");
        } elseif ($tipo_us == '2') {
            header("location: ../prod.php");
        } else {
            // En caso de un tipo de usuario no esperado, redirigir a una página de error o login
            echo '
                <script>
                    alert("¿Quién eres tu?, no existes");
                    window.location = "../login.php";
                </script>
            ';
        }
        exit;
    } else {
        // Si no se encontró el usuario, mostrar un mensaje de error y redirigir al login
        echo '
            <script>
                alert("Datos fallidos. Carita triste");
                window.location = "../login.php";
            </script>
        ';
        exit;
    }
?>
