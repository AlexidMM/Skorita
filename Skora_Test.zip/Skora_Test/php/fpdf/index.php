<html> 
<body>
    <div class="container">
        <div class="row">
            <!-- boton para reporte -->
             <form action="prod-reporte.php">
             <button type="submit" class="btn btn-warning">Buscar</button>
            </form>

</html>
