<?php
include 'conexion.php';
session_start();

$nom_us = $_SESSION['nom_us'];

if (isset($_POST['agregar_dir'])) {
    $calle = $_POST['calle'];
    $col = $_POST['col'];
    $ni = $_POST['ni'];
    $ne = $_POST['ne'];
    $cp = $_POST['cp'];

    $stmt = mysqli_prepare($conexion, "INSERT INTO DIRECCION (calle, col, ni, ne, cp) VALUES (?,?,?,?,?)");
    mysqli_stmt_bind_param($stmt, "sssss", $calle, $col, $ni, $ne, $cp);
    mysqli_stmt_execute($stmt);

    $id_dir = mysqli_insert_id($conexion);

    $stmt = mysqli_prepare($conexion, "UPDATE CLIENTE SET id_dir =? WHERE id_clie =?");
    mysqli_stmt_bind_param($stmt, "ii", $id_dir, $id_clie);
    mysqli_stmt_execute($stmt);
}

?>

<head>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" type="text/css" href="../assets/css/car_style.css">
    <title>Datos del cliente</title>
</head>

<h2>Datos del cliente</h2>

<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="POST">
    <label for="rfc_clie">RFC:</label>
    <input type="text" id="rfc_clie" name="rfc_clie" required><br><br>

    <label for="tel_clie">Teléfono:</label>
    <input type="tel" id="tel_clie" name="tel_clie" required><br><br>

    <?php
    $stmt = mysqli_prepare($conexion, "SELECT id_clie FROM CLIENTE WHERE nom_us =?");
    mysqli_stmt_bind_param($stmt, "s", $nom_us);
    mysqli_stmt_execute($stmt);
    $resultado = mysqli_stmt_get_result($stmt);
    $fila = mysqli_fetch_assoc($resultado);
    $id_clie = $fila['id_clie'];

    $stmt = mysqli_prepare($conexion, "SELECT d.* FROM DIRECCION d INNER JOIN CLIENTE c ON d.id_dir = c.id_dir WHERE c.id_clie =?");
    mysqli_stmt_bind_param($stmt, "i", $id_clie);
    mysqli_stmt_execute($stmt);
    $direcciones = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($direcciones) > 0) {
        // Mostrar direcciones existentes
        echo '<label for="id_dir">Dirección:</label>';
        echo '<select id="id_dir" name="id_dir" required>';
        while ($direccion = mysqli_fetch_assoc($direcciones)) {
            echo '<option value="'.$direccion['id_dir'].'">'.$direccion['calle'].' '.$direccion['col'].' '.$direccion['ni'].'-'.$direccion['ne'].' CP: '.$direccion['cp'].'</option>';
        }
        echo '</select><br><br>';
        echo '<button type="button" id="agregar_dir" class="btn btn-primary">Agregar nueva dirección</button>';
        echo '<div id="formulario_dir" style="display:none;">';
        echo '<label for="calle">Calle:</label>';
        echo '<input type="text" id="calle" name="calle" required><br><br>';
        echo '<label for="col">Colonia:</label>';
        echo '<input type="text" id="col" name="col" required><br><br>';
        echo '<label for="ni">Número interior:</label>';
        echo '<input type="text" id="ni" name="ni" required><br><br>';
        echo '<label for="ne">Número exterior:</label>';
        echo '<input type="text" id="ne" name="ne" required><br><br>';
        echo '<label for="cp">Código postal:</label>';
        echo '<input type="text" id="cp" name="cp" required><br><br>';
        echo '<input type="submit" name="agregar_dir" value="Agregar dirección">';
        echo '</div>';
    } else {
        // Mostrar formulario para agregar nueva dirección
        echo '<h3>No tienes direcciones registradas</h3>';
        echo '<label for="calle">Calle:</label>';
        echo '<input type="text" id="calle" name="calle" required><br><br>';
        echo '<label for="col">Colonia:</label>';
        echo '<input type="text" id="col" name="col" required><br><br>';
        echo '<label for="ni">Número interior:</label>';
        echo '<input type="text" id="ni" name="ni" required><br><br>';
        echo '<label for="ne">Número exterior:</label>';
        echo '<input type="text" id="ne" name="ne" required><br><br>';
        echo '<label for="cp">Código postal:</label>';
        echo '<input type="text" id="cp" name="cp" required><br><br>';
        echo '<input type="submit" name="agregar_dir" value="Agregar dirección">';
    }
 ?>

    <input type="submit" value="Continuar" class="btn btn-primary">
</form>

<div class="botones">
    <a href="carrito.php" class="btn btn-warning">Volver</a>
</div>

<script>
    document.getElementById('agregar_dir').addEventListener('click', function() {
        document.getElementById('formulario_dir').style.display = 'block';
    });
</script>