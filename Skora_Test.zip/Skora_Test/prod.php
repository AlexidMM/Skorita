<?php
session_start();
include 'php/conexion.php';

// Verificar si el usuario ha iniciado sesión y si es administrador
if (!isset($_SESSION['nom_us']) || $_SESSION['tipo_us']!= '2') {
    echo '
        <script>
            alert("Se tiene que ingresar Sesión primero.");
            window.location = "login.php";
        </script>
    ';
    exit;
}
if (!isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = array();
}

// Obtener categorías y productos
$categorias = array();
if (isset($_GET['buscar'])) {
    $buscar = $_GET['buscar'];
    $resultBus = mysqli_query($conexion, "SELECT c.id_cat, c.nom_cat, a.id_art, a.nom_art, a.prec_art, a.desc_art, a.img_art FROM ARTICULO a JOIN CATEGORIA c ON a.id_cat = c.id_cat WHERE a.nom_art LIKE '%$buscar%' OR c.nom_cat LIKE '%$buscar%' OR a.desc_art LIKE '%$buscar%'");
} else {
    $resultBus = mysqli_query($conexion, "SELECT c.id_cat, c.nom_cat, a.id_art, a.nom_art, a.prec_art, a.desc_art, a.img_art FROM ARTICULO a JOIN CATEGORIA c ON a.id_cat = c.id_cat WHERE a.Status = 'Activo'");
}
while ($row = mysqli_fetch_assoc($resultBus)) {
    $categorias[$row['nom_cat']][] = $row;
}

if (isset($_POST['id_art'])) {
    $id_art = $_POST['id_art'];
    $producto = mysqli_query($conexion, "SELECT * FROM ARTICULO WHERE id_art = '$id_art'");
    $producto = mysqli_fetch_assoc($producto);

    // Verificar si el producto ya está en el carrito
    $found = false;
    foreach ($_SESSION['carrito'] as &$item) {
        if ($item['id_art'] == $id_art) {
            $item['cantidad']++; // Incrementar cantidad en 1
            $found = true;
            break;
        }
    }

    // Agregar producto al carrito si no existe
    if (!$found) {
        $_SESSION['carrito'][] = array(
            'id_art' => $id_art,
            'nom_art' => $producto['nom_art'],
            'prec_art' => $producto['prec_art'],
            'cantidad' => 1
        );
    }

    // Actualizar contador de carrito
    $_SESSION['carrito_count'] = count($_SESSION['carrito']);

    header('Location: prod.php');
    exit;
}

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="assets/css/styleC.css">
    <title>Productos</title>
</head>

<body>

    <nav>
        <a href="index.html" class="logo">Skora</a>
        <div class="links">
            <a href="index.php">Inicio</a>
            <a href="prod.php">Categorias</a>
            <a href="contacto.html">Sobre Nosotros</a>
        </div>    
        <div class="links">
            <a href="php/carrito.php" id="cart-link">Carrito de compras <span id="cart-count">(<?php echo count($_SESSION['carrito']);?>)</span></a>
        </div>
        <form class="form-inline my-2 my-lg-0" action="prod.php" method="GET">
            <input class="form-control mr-sm-2" type="search" name="buscar" placeholder="Buscar" aria-label="Buscar" autocomplete="off">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Buscar</button>
        </form>
    </nav>

    <h2 class="separator">
        Nuestros mejores Productos!
    </h2>

    <div class="nft-shop">
        <div class="category">
            <a href="#">CARTERAS</a>
            <a href="#">BOLSOS</a>
            <a href="#">MOCHILAS</a>
            <a href="#">ZAPATOS</a>
            <a href="#">ROPA</a>
        </div>
        <?php foreach ($categorias as $categoria => $productos) { ?>
            <div class="category-container">
                <h2><?php echo $categoria; ?></h2>
                <div class="product-list">
                    <?php foreach ($productos as $producto) { ?>
                        <div class="product-container" style="margin-bottom: 20px;">
                            <img src="data:image/jpeg;base64,<?php echo base64_encode($producto['img_art']);?>" class="img-articulo">
                            <div class="product-info">
                                <h5><?php echo $producto['nom_art']; ?></h5>
                                <div class="btc">
                                    <p><i class="bx bxl-bitcoin"></i> <?php echo number_format($producto['prec_art'], 2); ?> MXN</p>
                                </div>
                                <p><?php echo $producto['desc_art']; ?></p>
                            </div>
                            <form action="prod.php" method="POST">
                                <input type="hidden" name="id_art" value="<?php echo $producto['id_art']; ?>">
                                <button type="submit" class="btn btn-primary">Agregar al carrito</button>
                            </form>
                        </div>
                    <?php } ?>
                </div>
            </div>
        <?php } ?>
    </div>

    <script src="assets/js/script.js"></script>
</body>

</html>